var BGcolor = [150, 250, 200]

function setup() {
  createCanvas(800, 600);
  background(BGcolor);
}

function draw() {
  fill(200, 50, 25)
  noStroke()
  if (mouseDragged) {
    if (mouseButton === RIGHT) {
      ellipse(BGcolor);
     }
}
   
}
function mouseDragged(){
  if (mouseButton === LEFT){
  ellipse(mouseX,mouseY,40,40)
  }
}
 