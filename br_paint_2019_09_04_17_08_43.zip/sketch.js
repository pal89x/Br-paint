function setup() {
  createCanvas(800, 600);
  background(150, 250, 200);
}

function draw() {
  fill(200, 50, 25)
  noStroke()
  ellipse(mouseX,mouseY, 89)
 
}

function mousePressed() {
background(150, 250, 200);
}

